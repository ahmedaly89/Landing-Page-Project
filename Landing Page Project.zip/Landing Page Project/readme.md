# Landing Page Project

## Table of Contents

* Nav Bar with unordered list
* List of three sections
* When clicking an item from the navigation menu, the link should scroll to the appropriate section
* Page is respositive to modern desktop, tablet, and phone browsers